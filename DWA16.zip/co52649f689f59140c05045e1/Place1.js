import React from 'react';


function Place1({ data }) {
  return (
    <div className="travel-journal">
      <h1>Travel Destinations</h1>
      {data.map(destination => (
        <div key={destination.title} className="destination-entry">
          <h2>{destination.title}</h2>
          <p>Location: {destination.location}</p>
          <p>Start Date: {destination.startDate}</p>
          <p>End Date: {destination.endDate}</p>
          <p>Description: {destination.description}</p>
          <a href={destination.googleMapsUrl} target="_blank" rel="noopener noreferrer">Google Maps Link</a>
          <img src={destination.imageUrl} alt={destination.title} />
        </div>
      ))}
    </div>
  );
}

export default Place1;
