export default [
    {id:1, 
        title: "Mount Fuji",
        location: "Japan",
        googleMapsUrl: "https://goo.gl/maps/1DGM5WrWnATgkSNB8",
        startDate: "12 Jan, 2021",
        endDate: "24 Jan, 2021",
        description: "Mount Fuji is the tallest mountain in Japan, standing at 3,776 meters (12,380 feet). Mount Fuji is the single most popular tourist site in Japan, for both Japanese and foreign tourists.",
        imageUrl: "https://source.unsplash.com/WLxQvbMyfas"
    },




 
  {
      id:2,
    title: "Grand Canyon",
    location: "Arizona, USA",
    googleMapsUrl: "https://goo.gl/maps/grandcanyon",
    startDate: "5 July, 2021",
    endDate: "10 July, 2021",
    description: "The Grand Canyon is a steep-sided canyon carved by the Colorado River in Arizona, United States. It is one of the Seven Natural Wonders of the World.",
    imageUrl: "https://source.unsplash.com/0JZKgGh7eX0"

  },
  
  
  
  
  {id:3,
    title: "Eiffel Tower",
    location: "Paris, France",
    googleMapsUrl: "https://goo.gl/maps/eiffeltower",
    startDate: "20 April, 2021",
    endDate: "25 April, 2021",
    description: "The Eiffel Tower is a wrought-iron lattice tower on the Champ de Mars in Paris, France. It is one of the most recognizable structures in the world.",
    imageUrl:"https://source.unsplash.com/PC_lbSSxCZE"
  }
];